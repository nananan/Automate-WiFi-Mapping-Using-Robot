corobot-ros-pkg
===============

ROS packages to control a CoroWare Corobot. The packages have been catkinized and work on ROS Groovy and after.
